const ws = require("nodejs-websocket")

let count =0;

const wsServer = ws.createServer((conn) => {
    conn.on("close", (code, reason) => {
        console.log("websocket:Connection closed")
    })
	conn.on('connect',res=>{
	})
    conn.on('text', async (msg) => {
        try {
            let sendData = {
                chartPage:{
                    msg:JSON.parse(msg)
                }
            };
            wsServer.connections.forEach(function(connection){
                connection.sendText(JSON.stringify(sendData));
            });
        } catch (error) {
			console.log(error)
        }
    })
    conn.on('error', (err) => {
        console.log(err)
    })

}).listen(9999)